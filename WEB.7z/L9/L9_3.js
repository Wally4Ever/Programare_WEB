/*
3. Să se implementeze o clasă JS numită Student cu următoarele atribute:
a. nume
b. prenume
c. data_n_nasterii
d. foaie_matricola (șir de valori numerice)
Clasa are metodele:
a. afiseazaVarsta(): returnează vârsta calculată în funcție de data_n nașterii
b. afiseazaNotele(): returnează un șir de caractere obținut prin alăturarea și separarea cu ‘,’ a
tuturor notelor existente
c. calculeazaMedia(): returnează media aritmetică a notelor existente
d. adaugaNota(nota_noua): adaugă în lista de note noua valoare primită ca parametru

Să se definească un șir de 3 studenți cu datele predefinite. Să se ordoneze și să se afișeze studenții:
- alfabetic, ținând cont de nume și prenume
- după medii
- după vârstă
3’.   Se vor adăuga noi valori pt. note și se va re-apela ordonarea după medii.
3’’.  Se vor schimba numele anumitor studenți și se va re-apela ordonarea alfabetică.
*/

class Student {
  constructor(prenume, nume, data_n, note) {
    this.prenume = prenume;
    this.nume = nume;
    this.data_n = data_n;
    this.note = note;
  }

  toString() {

    let day = this.data_n.getDate();
    let month = this.data_n.getMonth();
    let year = this.data_n.getFullYear();
    let format = day + "/" + month + "/" + year;
    return `${this.prenume} ${this.nume} nascut in ` +format+ ` are media ${this.outMedie()}` + '<br>';
  }

  outVarsta() {
    var age = Date.now() - this.data_n.getTime();

    return (new Date(age).getUTCFullYear() - 1970);
  }

  outNote() {
    return this.note.toString();
  }

  outMedie() {
    return this.note.reduce((acc, e) => acc += e) / this.note.length;
  }

  addNota(new_nota) {
    this.note.push(new_nota);
  }
}

var stud = [
  new Student("Valentin", "Ples", new Date(2002, 4, 7), [10, 10, 9, 10]),
  new Student("Ada", "Pirjol", new Date(2002, 8, 18), [6, 10, 4, 9]),
  new Student("Fufezan", "Mihai", new Date(2001, 9, 15), [8, 7, 3]),
  new Student("Maria", "Pop", new Date(2004, 1, 1), [4, 5, 6]),
];
var text;

function dupaNume(stud) {
  return stud.sort((a, b) => {
    const comp = a.nume.localeCompare(b.nume);
    if (comp === 0) {
      return a.prenume.localeCompare(b.prenume);
    }
    return comp;
  });
}
function dupaMedie(stud){
 return stud.sort((a, b) => b.outMedie() - a.outMedie());
}
function dupaVarsta(stud){
  return stud.sort((a, b) => a.outVarsta() - b.outVarsta());
}

function f1(){

//var sortati = dupaNume(stud);
text="Studentii:<br>";
text+= stud.toString();

dupaNume(stud);
text+="<br>Studenti sortati dupa nume si prenume:<br>";
text+= stud.toString();

dupaMedie(stud);
text+="<br>Studenti sortati dupa medie:<br>";
text+= stud.toString();

dupaVarsta(stud);
text+="<br>Studenti sortati dupa varsta:<br>";
text+= stud.toString();

for (var s of stud) {
  s.addNota(Math.round(Math.random() * 10));
}
dupaMedie(stud);
text+="<br>Adaugat note:<br>";
text+= stud.toString();

var n = ["Popescu", "Popa", "Popica"];
for (i = 0; i+1 < stud.length && i < n.length; i++) {
  stud[i].nume = n[i];
}
dupaNume(stud);
text+="<br>Studenti sortati dupa nume si prenume:<br>";
text+= stud.toString();

displayer.innerHTML = text;
}