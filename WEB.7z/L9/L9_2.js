/*Să se definească și să se populeze un șir de valori asociative denumit produse care face corespondența
între denumiri (o serie de chei de tip șir de caractere) și prețuri (valori numerice). Să se:
- afișeze cheile și valorile din șir prin tipărirea directă
- afișeze valorile din șir prin iterarea cheilor
- ordoneze produsele după preț și să se afișeze rezultatul*/

var prod = {
  apa: 2,
  pizza: 35,
  bere: 4,
  pita: 7,
  lapte: 6,
};

var text;

function f1()
{
  text= "Cheile si valorile din sir prin tiparirea directa: ";
  for (var k in prod) {
    text += "<br>&emsp;&emsp;Cheie: " + k + ", valoare: " + prod[k];
  }
  text+= "<br>Afisare iterare chei:<br>";
  for (var k in prod) {
    text += "&emsp;&emsp;Valoare:" + prod[k] + "<br>";
  }

  keys = Object.keys(prod);
  keys.sort();
  text+= "Ordonare dupa pret:";
  for(var k of keys) {
    text+="<br>&emsp;&emsp;Cheie: " + k + ", valoare: " + prod[k];
  }
displayer.innerHTML = text;
}