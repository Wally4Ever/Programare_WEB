/*Să se completeze clasa cu metode setter pt. atributele nume, prenume și data_nasterii. Se vor trata
exceptiile date de:
- siruri de caractere cu lungimea mai mică decât 2 sau care conțin caractere numerice;
- date de naștere mai recente de 18 ani.
Excepțiile se tratează prin setarea unor valori implicite și afișarea unor mesaje în consola browser-ului.*/
var varsta = (date) => {
  let age = Date.now() - date.getTime();
  return (new Date(age).getUTCFullYear() - 1970);
};
var setName = (name, obj, prop) => {
  try {
    if (name.length < 2) {
      throw "Scurt!";
    } else if (!/^[a-zA-Z]*$/.test(name)) {
      throw "Fara numere!";
    }
    obj[prop] = name;
  } catch (err) {
    console.log(err);
  }
};

class Student {
  constructor(prenume, nume, data_n, note) {
    this.prenume = prenume;
    this.nume = nume;
    this.data_n = data_n;
    this.note = note;
  }

  toString = () => {

    let day = this.data_n.getDate();
    let month = this.data_n.getMonth();
    let year = this.data_n.getFullYear();
    let format = day + "/" + month + "/" + year;
    return `${this.prenume} ${this.nume} nascut in ` +format+ ` are media ${this.outMedie()}` + '<br>';
  }

  outVarsta = () => varsta(this.data_n);

  outNote = () => this.note.toString();
  

  outMedie = () => this.note.reduce((acc, e) => acc += e) / this.note.length;
  

  addNota = (new_nota) => this.note.push(new_nota);

  setData_n = (data_n) => {
    try {
      if (varsta(data_n) < 18) {
        throw "Age cannot be lower than 18";
      }
      this.data_n = data_n;
    } catch (err) {
      console.log(err);
    }
  }
  setNume = (name) => setName(name, this, "nume");
  setPrenume = (name) => setName(name, this, "prenume");
  
}

var stud = [
  new Student("Valentin", "Ples", new Date(2002, 4, 7), [10, 10, 9, 10]),
  new Student("Ada", "Pirjol", new Date(2002, 8, 18), [6, 10, 4, 9]),
  new Student("Fufezan", "Mihai", new Date(2001, 9, 15), [8, 7, 3]),
  new Student("Maria", "Pop", new Date(2004, 1, 1), [4, 5, 6]),
];
var text;

dupaNume = (stud) => {
  return stud.sort((a, b) => {
    const comp = a.nume.localeCompare(b.nume);
    if (comp === 0) {
      return a.prenume.localeCompare(b.prenume);
    }
    return comp;
  });
}
dupaMedie = (stud) => stud.sort((a, b) => b.outMedie() - a.outMedie());

dupaVarsta = (stud) => stud.sort((a, b) => a.outVarsta() - b.outVarsta());

function f1(){

//var sortati = dupaNume(stud);
text="Studentii:<br>";
text+= stud.toString();

dupaNume(stud);
text+="<br>Studenti sortati dupa nume si prenume:<br>";
text+= stud.toString();

dupaMedie(stud);
text+="<br>Studenti sortati dupa medie:<br>";
text+= stud.toString();

dupaVarsta(stud);
text+="<br>Studenti sortati dupa varsta:<br>";
text+= stud.toString();

for (var s of stud) {
  s.addNota(Math.round(Math.random() * 10));
}
dupaMedie(stud);
text+="<br>Adaugat note:<br>";
text+= stud.toString();

var n = ["Popescu", "Popa", "Popica"];
for (i = 0; i+1 < stud.length && i < n.length; i++) {
  stud[i].nume = n[i];
}
dupaNume(stud);
text+="<br>Studenti sortati dupa nume si prenume:<br>";
text+= stud.toString();


displayer.innerHTML = text;
}