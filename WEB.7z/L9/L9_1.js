/*Să se definească și să se populeze un șir de valori numerice. Să se efectueze:
- ordonarea crescătoare și descrescătoare a valorilor din șir
- eliminarea din șir a valorilor pare
- introducerea în șir a elementelor unui alt șir predefinit*/
var text; 
var arr = [1, 2, 9, 11, 23, 6, 15, 8, 12];
var sir=[69, 420, 80085, 13];

function f1()
{
        displayer = document.getElementById("displayer");
        text= "Sirul initial este: "+ arr;

        arr.sort();
        text+="<br><br>Sir ordonat crescator: "+arr;

        arr.reverse();
        text+="<br><br>Sir ordonat descrescator: "+arr;
        
        for (i=0; i<arr.length; i++)
                if  (arr[i]%2==0)
                        arr.splice(i, 1);
        text+="<br><br>Sir fara valori pare: "+arr;
        
        for (i=0; i<arr.length && i<sir.length; i++)
                if  (!(arr.includes(sir[i])))
                {
                        arr.splice(i, 0, sir[i]);
                }
        text+="<br><br>Sir cu elemente diferite din celalalt sir: "+arr;
        displayer.innerHTML = text;
}

