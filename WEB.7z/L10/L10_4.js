/**Dezvoltați o pagină web cu facilități JavaScript care definește un text. În 3 componente de tip div
(existente în pagină) se vor afișa:
- caracterele care reprezintă litere
- caracterele care reprezintă cifre
- textul obținut prin înlocuirea cifrelor cu caracterul *
 */
function f1() {
    var d = document.getElementById('d');

    var txt = "80085Papagalii420sunt69oameni112sau189231de321ce0192stiu0392sa19vorbeasca?";


    var dL = document.createElement('div');
    var dNr = document.createElement('div');
    var dNew = document.createElement('div');

    var letters = txt.replace(/[0-9]/g, '');
    dL.textContent = "Litere: " + letters;

   
    var numbersOnly = txt.replace(/[^0-9]/g, '');
    dNr.textContent = "Numere: " + numbersOnly;

    var replacedText = txt.replace(/\d/g, '*');
    dNew.textContent = "Stelutze (fortza steaua): " + replacedText;
   
    d.appendChild(dL);
    d.appendChild(dNr);
    d.appendChild(dNew);
}

