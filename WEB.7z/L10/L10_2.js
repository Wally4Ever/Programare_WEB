/*Dezvoltați o pagină web cu facilități JavaScript care desenează, una langa alta,
- o serie de componente (10) div colorate cu culori prestabilite
- o serie de componente (10) div colorate cu culori generate aleator */
function getRandomColor() {
    var letters = '0123456789ABCDEF';
    var color = '#';
    for (var i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}
function f1(){
    
    var d = document.getElementById('d');

   //culori prestabilite
    for (var i = 0; i < 10; i++) {
        var pc = document.createElement('div');
        pc.style.width = '70px';
        pc.style.height = '70px';
        pc.style.margin = '5px';
        pc.style.display = 'inline-block';
        pc.style.border = '1px solid #000';
        pc.style.backgroundColor = ['red', 'green', 'blue', 'yellow', 'orange', 'purple', 'pink', 'brown', 'cyan', 'magenta'][i];
        d.appendChild(pc);
    }

    // culori generate aleator
    for (var i = 0; i < 10; i++) {
        var rc = document.createElement('div');
        rc.style.width = '70px';
        rc.style.height = '70px';
        rc.style.margin = '5px';
        rc.style.display = 'inline-block';
        rc.style.border = '1px solid #000';
        rc.style.backgroundColor = getRandomColor();
        d.appendChild(rc);
    }
}