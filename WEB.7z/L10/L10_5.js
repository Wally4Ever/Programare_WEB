/**Dezvoltați o pagină web cu facilități JavaScript care definește un șir de valori numerice întregi. În 3
componente de tip div (existente în pagină) se vor afișa:
- valorile pozitive par
- numărul de elemente negative care sunt compuse din mai mult de 2 cifre, urmat de respectivele elemente
- valorile care reprezintă minime locale (sunt încadrate de valori mai mari) */
function f1() {

    var d = document.getElementById('d');

    var dPar = document.createElement('div');
    var dNeg = document.createElement('div');
    var dMin = document.createElement('div');

    d.appendChild(dPar);
    d.appendChild(dNeg);
    d.appendChild(dMin);


    var ints = [12, -555, 11, 10, 8, 9, -141, 25, -420, 6, 9, -10];

    var par = ints.filter(num => num > 0 && num % 2 === 0);
    dPar.textContent = "Valori pozitive pare: " + par.join(', ');

    var neg = ints.filter(num => num < -99);
    dNeg.textContent = "(" + neg.length + ") Mai mici de -99: " + neg.join(', ');

    var min = [];
    for (var i = 1; i < ints.length - 1; i++)
        if (ints[i] < ints[i - 1] && ints[i] < ints[i + 1])
            min.push(ints[i]);

    dMin.textContent = "Minim local: " + min.toString();
}



