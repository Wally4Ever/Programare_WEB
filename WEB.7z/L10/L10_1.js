/*Dezvoltați o pagină web cu facilități JavaScript care obține o referință la o componentă de tip div
existentă în pagină. Folosind referința,
- modificați culoarea de background a componentei
- afișați în componentă un text predefinit
- afișați în componentă 
    -un alt element de tip div 
    - un text încapsulat într-un tag p
    - o imagine cu referința spre o resursă web*/

function f1() {

    var d = document.getElementById('d');
    d.style.backgroundColor = '#10efef';

    var txt = document.createTextNode('Pateu vegetal de ardei.');
    d.appendChild(txt);

    var inD = document.createElement('div');
    inD.style.backgroundColor = '#3fff11';
    inD.style.padding = '10px';
    inD.style.border = '2px solid red';
    inD.innerHTML = 'Pizza cu Ananas in spatele gratiilor de DIV.';
    d.appendChild(inD);

    var p = document.createElement('p');
    p.innerHTML = 'Gogonele murate la paragraf.';
    d.appendChild(p);

    var img = document.createElement('img');
    img.src = 'jack.jpg';
    img.alt = 'Pacat frate, era o poza foarte jmechera aici';
    d.appendChild(img);
    
    img.addEventListener('click', () => window.location.href = "https://pointerpointer.com");

}