/**. Dezvoltați o pagină web cu facilități JavaScript care definește și randează o grilă dreptunghiulară
(componente div alăturate, dispuse matricial; dimensiunea grilei este prestabilită). Componentele vor fi
colorate diferit în funcție de valorile 0 sau 1 memorate într-o matrice. Pozițiile ocupate de elementele din
matrice definesc corespondența cu elementele de pe ecran */



function f1() {

    var matrix = [
        [0, 1, 0, 1, 0],
        [1, 0, 1, 0, 1],
        [0, 1, 0, 1, 0],
        [1, 0, 1, 0, 1],
        [0, 1, 0, 1, 0]
    ];


    var d = document.getElementById('d');

    /*
    In the middle of the screen
    
    d.style.position = 'absolute';
    d.style.top = '20%';
    d.style.left = '30%';
    d.style.padding = '5px';
    d.style.border = 'none';*/


    d.style.border = 'none';

    for (var i = 0; i < matrix.length; i++) {
        for (var j = 0; j < matrix[i].length; j++) {

            var x = document.createElement('div');

            x.style.width = '100px';
            x.style.height = '100px';
            x.style.display = 'inline-block';
            x.style.margin = '1px';
            x.style.border = "2px solid blue";

            x.style.backgroundColor = matrix[i][j] == 0 ? '#fff' : '#000';
            d.appendChild(x);
        }
        d.appendChild(document.createElement('br'));
    }

}