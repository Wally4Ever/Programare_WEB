﻿CREATE DATABASE Firma
GO


USE FIRMA
GO

--Tabela Departamente
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DEPARTAMENTE]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[DEPARTAMENTE]
GO

CREATE TABLE DEPARTAMENTE (
 IdDept int PRIMARY KEY IDENTITY,
 Denumire varchar(30) NOT NULL
)
GO


-- Tabela Functii
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FUNCTII]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[FUNCTII]
GO

CREATE TABLE FUNCTII (
 IdFunctie int PRIMARY KEY IDENTITY,
 Denumire varchar(30) NOT NULL,
 Salariu int CHECK (Salariu > 0)
)
GO


-- Tabela Angajati
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ANGAJATI]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ANGAJATI]
GO

CREATE TABLE ANGAJATI (
 IdAngajat int PRIMARY KEY IDENTITY,
 Nume varchar(20) NOT NULL,
 Prenume varchar(20) NOT NULL,
 Marca int NOT NULL UNIQUE,
 DataNasterii date,
 DataAngajarii date,
 Adresa_jud varchar(20) NOT NULL,
 IdFunctie int NOT NULL,
 IdDept int NOT NULL
)
GO


-- Tabela Clienti
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[CLIENTI]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[CLIENTI]
GO

CREATE TABLE CLIENTI (
 IdClient int PRIMARY KEY IDENTITY,
 Denumire varchar(20) NOT NULL,
 Tip_cl varchar(10) NOT NULL, -- PF, PFA, SRL, SA, RA
 Adresa_jud varchar(20) NOT NULL
)
GO


-- Tabela Categorii_prod
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[CATEGORII_PROD]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[CATEGORII_PROD]
GO

CREATE TABLE CATEGORII_PROD (
 IdCateg int PRIMARY KEY IDENTITY,
 Denumire varchar(20) NOT NULL
)
GO


-- Tabela Produse
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[PRODUSE]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[PRODUSE]
GO

CREATE TABLE PRODUSE (
 IdProdus int PRIMARY KEY IDENTITY,
 Denumire varchar(36) NOT NULL,
 IdCateg int NOT NULL
)
GO


-- Tabela Vanzari
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[VANZARI]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[VANZARI]
GO

CREATE TABLE VANZARI (
 IdVanzare int PRIMARY KEY IDENTITY,
 IDProdus int NOT NULL,
 IDClient int NOT NULL,
 IDVanzator int NOT NULL,
 DataVanz date DEFAULT GetDate(),
 NrProduse int DEFAULT 1 CHECK (NrProduse > 0),
 PretVanz int CHECK (PretVanz > 0)
)
GO

--Să se introducă un câmp nou (Cod_produs CHAR(6)) în tabela Produse ce admite numai
--valori unice. Să se introduca produse noi cu date pentru Cod_produs
ALTER TABLE produse ADD Cod_produs CHAR(6)

--Să se introducă o constrângere ce verifică că în câmpul Tip_cl din tabela Clienti se pot
--introduce numai valorile: PF, PFA, SRL, SA. Să se verifice funcționarea constrângerii.
ALTER TABLE Clienti ADD CONSTRAINT tip_client 
        CHECK (Tip_cl = 'PF' OR Tip_cl = 'SRL' OR Tip_cl = 'PFA' OR Tip_cl = 'SA')

        --Să se introducă o constrângere ce verifică că în câmpul Datavanz din tabela Vanzari nu se
--pot introduce date din viitor (se folosesc funcțiile GETDATE și DATEDIFF). Să se verifice
--funcționarea constrângerii.

ALTER TABLE VANZARI ADD CONSTRAINT data_vanzarii 
        CHECK (DATEDIFF(day, Datavanz, GETDATE())>0)

--Să se șteargă toți clienții dintr-un anumit judet.

--Să se șteargă toate vânzările mai vechi de 1 an
 
--Să se șteargă angajații din departamentul PROIECTARE, angajați dupa 01.01.2018 (se folosește funcția DATEDIFF)

 --Să se transfere toți angajații cu vechime mai mare de 5 ani, din departamentul  în departamentul VANZARI.

 --Să se adauge secvența ’-v2’ (se folosește funcția CONCAT) la toate denumirile de produse cu valoarea cheii primare numere impare.

  --Să se modifice prețul de vânzare (creștere cu 10%) la toate produsele din categoria ADAPTOARE vândute în după o anumită dată.