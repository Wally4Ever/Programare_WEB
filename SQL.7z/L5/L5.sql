﻿﻿GO
CREATE VIEW vAngajati AS
SELECT A.IdAngajat, A.Nume, A.Prenume,
D.Denumire AS Departament,
F.Denumire AS Functie, F.Salariu, A.
DataNasterii, A.DataAngajarii
FROM Angajati A, Departamente D, Functii F
WHERE A.IdDept=D.IdDept AND A.IdFunctie=F.IdFunctie
GO
SELECT * FROM vAngajati
GO

SELECT Nume, Prenume
FROM vAngajati
WHERE Departament = 'PRODUCTIE'

SELECT Nume, Prenume, Departament
FROM vAngajati
WHERE Departament = 'PROIECTARE'
ORDER BY Nume, Prenume

SELECT Functie, AVG(Salariu) SalMed
FROM vAngajati
GROUP BY Functie
ORDER BY SalMed DESC

SELECT COUNT(*) NrAng
FROM vAngajati

--Care sunt angajații dintr-un anumit departament a căror nume conține caracterele ‘escu’ ?
SELECT Nume, Departament
FROM vAngajati 
WHERE Departament = 'PROIECTARE' AND Nume LIKE '%1%'

--Care sunt angajații dintr-un anumit departament a căror nume începe cu caracterele ‘po’ 
SELECT Nume, Departament
FROM vAngajati 
WHERE Departament = 'VANZARI' AND Nume LIKE 'N1%'

--Care sunt angajații dintr-un anumit departament (dat prin denumire) (opțional: ordonați după salariu crescător/descrescător
SELECT Nume, Prenume, Salariu as BANI
FROM vAngajati
WHERE Departament = 'MANAGEMENT' ORDER BY Salariu

--Câți angajați sunt într-un anumit departament dat prin denumire ?
SELECT COUNT(IdAngajat) as Nr_Angajati
FROM vAngajati
WHERE Departament = 'PRODUCTIE'

--Care este suma salariilor angajaților din companie ? 
SELECT SUM(Salariu) as BANI
FROM vAngajati

--1. Care este media salariilor pe un departament specificat prin nume ? (AVG)
SELECT AVG(Salariu) as Salariu_mediu_Productie
FROM vAngajati
WHERE Departament = 'PRODUCTIE'

--2. Care sunt mediile salariilor angajaților grupate pe funcții) ? (AVG, GROUP BY)
SELECT Functie, AVG(Salariu) as Salariu_mediu_functie
FROM vAngajati
GROUP BY Functie

--3. Care este cel mai mic/mare salariu din companie ? (MIN, MAX)
SELECT MIN(Salariu) as cel_mai_sarac
FROM vAngajati

SELECT Nume, Salariu
FROM vAngajati
WHERE Salariu = (SELECT MIN(Salariu) FROM vAngajati);

--4. Care este cel mai mic/mare salariu dintr-un departament specificat ? (MIN, MAX)
SELECT Nume, Salariu
FROM vAngajati
WHERE Salariu = (SELECT MAX(Salariu) FROM vAngajati WHERE Departament = 'Productie') AND Departament= 'Productie'

SELECT MAX(Salariu) as cel_mai_bogat
FROM vAngajati
 WHERE Departament = 'Productie'

--5. Care sunt cele mai mici și cele mai mari salarii pe departamente ? (MIN, MAX, GROUP BY)
SELECT Departament, MIN(Salariu) as cel_mai_sarac, MAX(Salariu) as cel_mai_bogat
FROM vAngajati
GROUP BY Departament

--6. Câți angajați sunt în fiecare departament ? (COUNT, GROUP BY)
SELECT Departament, COUNT(IdAngajat) AS Nr_ang 
FROM vAngajati GROUP BY Departament

--7. Care este suma salariilor angajaților din fiecare departament ? (SUM, GROUP BY)
SELECT Departament, SUM(Salariu) AS totAL_bani 
FROM vAngajati GROUP BY Departament

--8. Listați angajații, grupati pe departamente și vechimi (rotunjite la an) ? (GROUP BY)
SELECT Nume, Prenume, Departament, DATEDIFF(year, DataAngajarii, GETDATE()) AS Vechime 
FROM vAngajati ORDER BY Departament,  Vechime

--9. Care sunt angajații, grupați pe funcții, ce au o vechime mai mare de 10 ani ? (GROUP BY)
SELECT Functie, COUNT(IdAngajat) AS Nr_Ang
FROM vAngajati WHERE (DATEDIFF(year, DataAngajarii, GETDATE())>10) GROUP BY Functie

--10. Care sunt angajații, grupați pe departamente, ce au vârsta de minim 30 ani ? (GROUP BY)
SELECT Functie, COUNT(IdAngajat) AS Batrani
FROM vAngajati WHERE (DATEDIFF(year, DataNasterii, GETDATE())>30) GROUP BY Functie

--11. Care sunt departamentele care au media salariilor mai mare decat 3000 ? (AVG, GROUP BY)
SELECT Departament, AVG(Salariu) AS Avg_pay
FROM vAngajati GROUP BY Departament HAVING AVG(Salariu)>5000
