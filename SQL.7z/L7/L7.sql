﻿USE Firma

GO
CREATE FUNCTION udf_SalarMediu(@departament varchar(20))
RETURNS decimal
AS BEGIN
	DECLARE @vm decimal;
	SELECT @vm = AVG(F.Salariu)
	FROM ANGAJATI A JOIN DEPARTAMENTE D ON A.IdDept = D. IdDept
		JOIN Functii F ON A.IdFunctie = F.IdFunctie
		WHERE D.Denumire = @departament
	RETURN @vm
END
GO
SELECT dbo.udf_SalarMediu('PRODUCTIE') SalMediu
SELECT D.Denumire, dbo.udf_SalarMediu(D.Denumire) SalMediu
FROM DEPARTAMENTE D
ORDER BY SalMediu DESC, D.Denumire

--Scrieți și testați o funcție ce permite validarea unui nou câmp CNP scurt (din tabela Angajati), avand următoarea structură: G AA LL ZZ.
CREATE FUNCTION udf_ValidCNP(@cnp varchar(10))
RETURNS BIT
AS BEGIN
	DECLARE @rez bit
		IF @cnp LIKE '[1-8][0-9][0-1][0-9][0-3][0-9][0-9][0-9]'
			SET @rez=1
		ELSE 
			SET @rez=0
	RETURN @rez
END
SELECT dbo.udf_ValidCNP('55053555')
SELECT dbo.udf_ValidCNP('19611234')

--o Scrieți și testați o funcție ce permite verificarea faptului că un vânzător face parte
--din departamentul VANZARI.
CREATE FUNCTION is_Vanz(@Id int)
RETURNS bit
AS BEGIN
    DECLARE @Result bit
    IF EXISTS (SELECT 1 FROM ANGAJATI a JOIN DEPARTAMENTE d ON a.IdDept = d.IdDept WHERE a.IdAngajat = @Id AND d.Denumire = 'VANZARI')
        SET @Result = 1
    ELSE
        SET @Result = 0

    RETURN @Result
END
SELECT dbo.is_Vanz(13)
SELECT dbo.is_Vanz(11)
--o Scrieți și testați o funcție care verifică dacă vârsta la angajare este de minim 18 ani.
CREATE FUNCTION Major (@Id int)
RETURNS BIT
AS BEGIN
	DECLARE @rez bit
	IF EXISTS (SELECT 1 FROM ANGAJATI WHERE IdAngajat = @Id 
				AND DATEDIFF(year, DataNasterii, DataAngajarii) >= 18)
				SET @rez=1
	ELSE
				SET @rez=0
	RETURN @rez
END
SELECT dbo.Major(11)

UPDATE ANGAJATI
SET DataNasterii = '2010-07-07'
WHERE IdAngajat = 8
SELECT dbo.Major(8)
--o Scrieți și testați o funcție ce determină suma vânzărilor pentru o categorie de
--produse dată ca parametru.
CREATE FUNCTION vanzari_categ (@Id int)
RETURNS INT
AS BEGIN
	DECLARE @Sum int
	SELECT @Sum = SUM(V.PretVanz * V.NrProduse)
	FROM VANZARI V
	JOIN PRODUSE P ON P.IdProdus=V.IDProdus
	WHERE P.IdCateg = @Id
	RETURN @Sum
END
SELECT dbo.vanzari_categ(3)
SELECT dbo.vanzari_categ(11)
--o Scrieți și testați o funcție ce determină valoarea medie a vânzărilor pe un interval de
--timp transmis prin parametri.
CREATE FUNCTION vanzari_interval (@start date, @end date)
RETURNS decimal
AS BEGIN
	DECLARE @Avg int
	SELECT @Avg = AVG(PretVanz * NrProduse)
	FROM VANZARI
	WHERE DataVanz BETWEEN @start AND @end
	RETURN @Avg
END
SELECT dbo.vanzari_interval('2000-01-30', '2023-01-01')
SELECT dbo.vanzari_interval('2022-01-30', '2023-01-01')
--Scrieți și testați o funcție in-line care returnează primii cei mai prost plătiți 3 angajați
--pentru un departament dat ca parametru.
CREATE FUNCTION trei_saraci_departament(@Id int)
RETURNS TABLE 
AS 
RETURN 
(
	SELECT TOP 3  A.Nume, F.Salariu
	FROM ANGAJATI A JOIN FUNCTII F ON A.IdFunctie = F.IdFunctie
	WHERE A.IdDept=@Id
	ORDER BY F.Salariu
)
DROP FUNCTION dbo.trei_saraci_departament
SELECT * FROM trei_saraci_departament(3)
--o Creați și testați o funcție care să returneze denumirea produselor și cantitățile pentru
--cele mai prost vândute 5 produse (valoric), având un an și o lună specificate ca
--parametri.
CREATE FUNCTION produse_naspa(@an int, @luna int)
RETURNS TABLE
AS
RETURN
(
	SELECT TOP 5 P.Denumire, SUM(V.NrProduse) AS Cantitate
	FROM PRODUSE P JOIN VANZARI V ON V.IDProdus=P.IdProdus
	WHERE YEAR(V.DataVanz) = @an AND MONTH(v.DataVanz) = @luna
	GROUP BY P.Denumire
	ORDER BY SUM(v.NrProduse)
)
SELECT * FROM produse_naspa(2016, 6)
--o Scrieți și testați o funcție care returnează lista angajaților cu vârsta și vechimea în
--muncă pentru un departament dat ca parametru.CREATE FUNCTION angajati_departament(@Id int)
RETURNS TABLE
AS
RETURN
(
	SELECT Nume, Prenume, DATEDIFF(year, DataNasterii, GETDATE()) AS Varsta, DATEDIFF(year, DataAngajarii, GETDATE()) AS Vechime
    FROM ANGAJATI
    WHERE IdDept = @Id
)
SELECT * FROM angajati_departament(3)
--1. Scrieți și testați o funcție care returnează angajații a căror funcții conține o secvență de
--caractere primită ca parametru ?
CREATE FUNCTION ang_func (@seq varchar(20))
RETURNS TABLE
AS
RETURN
(
	SELECT A.Nume, F.Denumire AS Functie
	FROM ANGAJATI A JOIN FUNCTII F ON A.IdFunctie=F.IdFunctie
	WHERE F.Denumire LIKE '%' + @seq + '%'
)
SELECT * FROM dbo.ang_func('dir')
--2. Scrieți și testați o funcție care returnează salariile dintr-un departament primit ca parametru?
--Câți angajați beneficiază de fiecare salariu?
CREATE FUNCTION salari_departament (@Id int)
RETURNS TABLE
AS
RETURN
(
	SELECT F.Salariu, COUNT(A.IdAngajat) AS NrAng
	FROM FUNCTII F JOIN ANGAJATI A ON F.IdFunctie = A.IdFunctie 
	WHERE A.IdDept = @Id
	GROUP BY F.Salariu
)
SELECT * FROM salari_departament(3)
--3. Scrieți și testați o funcție care returnează salariul minim și maxim dintr-un departament primit
--ca parametru?
CREATE FUNCTION min_max_departament(@Id int)
RETURNS TABLE
AS
RETURN
(
	SELECT MIN(F.Salariu) AS Sarakie, MAX(F.Salariu) AS Bogatzie
	FROM FUNCTII F JOIN ANGAJATI A ON A.IdFunctie=F.IdFunctie
	WHERE A.IdDept = @Id
)
SELECT * FROM min_max_departament(3)
--4. Scrieți și testați o funcție care returnează produsele vândute într-o anumită perioadă de timp?
--Limitele perioadei de timp sunt trimise ca parametri către funcție.
CREATE FUNCTION vandute_interval(@start date, @end date)
RETURNS TABLE
AS
RETURN
(
	SELECT P.Denumire, SUM(V.NrProduse) AS Cantitate
	FROM PRODUSE P JOIN VANZARI V ON V.IDProdus=P.IdProdus
	WHERE V.DataVanz BETWEEN @start AND @end
	GROUP BY P.Denumire
)
SELECT * FROM vandute_interval('2017-01-30', '2023-01-01')
--5. Scrieți și testați o funcție care returnează suma totală încasată de un vânzător al cărui nume
--este trimis ca parametru. Scrieți si testați o funcție care se bazează pe prima și care verifică
--dacă suma depășește un anumit prag minim trimis ca parametru. Afișați angajații care au
--vândut produse în valoare mai mare decât 100 RON.
CREATE FUNCTION suma_vanzator(@nume varchar(20))
RETURNS INT
AS
BEGIN
	DECLARE @sum int 
	SELECT @sum = SUM(V.PretVanz * V.NrProduse)
	FROM VANZARI V JOIN ANGAJATI A ON A.IdAngajat = V.IDVanzator
	WHERE A.Nume=@nume
	RETURN @sum
END

SELECT dbo.suma_vanzator('N13')

CREATE FUNCTION prag_vanzari (@nume varchar(20), @prag int)
RETURNS int
AS 
BEGIN 
	IF dbo.suma_vanzator(@nume) > @prag
		RETURN 1
	ELSE
		RETURN 0
	RETURN 0
END
SELECT dbo.prag_vanzari('n13', 500)
SELECT dbo.prag_vanzari('n13', 800)

SELECT Nume, Prenume
FROM ANGAJATI 
WHERE dbo.prag_vanzari(Nume, 500) = 1
--6. Scrieți și testați o funcție care returnează cele mai vândute N produse, într-o anumită perioadă
--de timp. Valoarea lui N și limitele perioadei de timp sunt trimise ca parametri către funcție.
CREATE FUNCTION prod_populare_interval(@n int, @start date, @end date)
RETURNS TABLE
AS
RETURN
(
	SELECT TOP (@n) P.Denumire, SUM(V.NrProduse) AS Cantitate
	FROM PRODUSE P JOIN VANZARI V ON P.IdProdus = V.IDProdus
	WHERE V.DataVanz BETWEEN @start AND @end
	GROUP BY P.Denumire
)
SELECT * FROM prod_populare_interval(3, '2016-01-30', '2023-01-01')
--7. Scrieți și testați o funcție care returnează clienții ordonați descrescător după sumele cheltuite,
--într-o anumită perioadă de timp ale cărei limite sunt trimise ca parametri.
CREATE FUNCTION clienti_interval(@start date, @end date)
RETURNS TABLE 
AS
RETURN
(
	SELECT TOP 100 C.Denumire, SUM(v.PretVanz * v.NrProduse) AS Cheltuit
	FROM CLIENTI C JOIN VANZARI V ON V.IDClient=C.IdClient
	WHERE V.DataVanz BETWEEN @start AND @end
	GROUP BY C.Denumire
	ORDER BY SUM(v.PretVanz * v.NrProduse) DESC
	--DE CE nu pot ordona fara "TOP" ????
)
SELECT * FROM clienti_interval('2016-01-30', '2023-01-01')