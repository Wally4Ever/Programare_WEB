﻿SELECT A.Nume, A.Prenume, F.Salariu
FROM Angajati A, Departamente D, Functii F
WHERE (A.IdDept = D.IdDept AND A.IdFunctie = F.IdFunctie) AND D.Denumire = 'PRODUCTIE'
ORDER BY F.salariu DESC, A.nume, A.prenume

SELECT A.Nume, A.Prenume, F.Salariu
FROM Angajati A
JOIN Departamente D ON A.IdDept = D.IdDept
JOIN Functii F ON A.IdFunctie = F.IdFunctie
WHERE D.Denumire = 'PRODUCTIE'
ORDER BY F.salariu DESC, A.nume, A.prenume

SELECT A.Nume, A.Prenume, D.Denumire Departament
FROM Angajati A JOIN Departamente D
ON (A.IdDept = D.IdDept)
WHERE (D.Denumire = 'PROIECTARE')
ORDER BY Nume, Prenume

SELECT F.Denumire, avg(F.Salariu) Sal_med
FROM Angajati A JOIN Functii F
ON (A.IdFunctie = F.IdFunctie)
GROUP BY F.Denumire

SELECT F.Denumire AS Functia, Sum(F.Salariu) Total_sal
FROM Angajati A JOIN Functii F
ON (A.IdFunctie = F.IdFunctie)
GROUP BY F.Denumire
ORDER BY Sum(F.Salariu) DESC

--1. Care sunt angajații dintr-un anumit departament (dat prin denumire) a căror nume începe
--cu caracterele ‘N1’ ?
SELECT A.Nume, D.Denumire
FROM ANGAJATI A JOIN DEPARTAMENTE D ON (A.IdDept=D.IdDept)
WHERE A.Nume LIKE 'N1%'

--2. Care sunt angajații dintr-un anumit departament (dat prin denumire) ordonați după salariu
--crescător/descrescător ?
SELECT A.Nume, D.Denumire, F.Salariu
FROM ANGAJATI A 
JOIN DEPARTAMENTE D ON (A.IdDept=D.IdDept)
JOIN FUNCTII F ON (A.IdFunctie=F.IdFunctie)
WHERE D.Denumire LIKE 'PRODUCTIE'
ORDER BY F.Salariu DESC


--3. Câți angajați sunt într-un anumit departament dat prin denumire ?
SELECT D.Denumire, COUNT(A.IdAngajat)
FROM ANGAJATI A 
JOIN DEPARTAMENTE D ON (A.IdDept=D.IdDept)
WHERE D.Denumire LIKE 'PRODUCTIE'
GROUP BY D.Denumire

--4. Care este suma salariilor angajaților din companie ?
SELECT SUM(F.Salariu) AS BANI
FROM ANGAJATI A 
JOIN FUNCTII F ON (A.IdFunctie=F.IdFunctie)

SELECT SUM(F.Salariu) AS BANI
FROM ANGAJATI A, FUNCTII F
WHERE A.IdFunctie=F.IdFunctie

--1. Care sunt angajații a căror funcții conține secvența de caractere ‘ngi’ ?
SELECT A.Nume, A.Prenume, F.Denumire, F.Salariu
FROM ANGAJATI A 
JOIN FUNCTII F ON (A.IdFunctie=F.IdFunctie)
WHERE F.Denumire LIKE '%ngi%'


--2-. Care sunt salariile din departamentul ‘PRODUCTIE’ și câți angajați au aceste salarii ? cati lucreaza pe aceasta functie
SELECT COUNT(A.IdAngajat)  Nr_ang, F.Denumire Functie, AVG(F.Salariu) Salarii
FROM ANGAJATI A 
JOIN DEPARTAMENTE D ON (A.IdDept=D.IdDept)
JOIN FUNCTII F ON (A.IdFunctie=F.IdFunctie)
WHERE D.Denumire LIKE 'PRODUCTIE'
GROUP BY F.Denumire


--3. Care sunt cele mai mici/mari salarii din departamente ?
SELECT  D.Denumire, MIN(F.Salariu) AS Sarakie
FROM ANGAJATI A
JOIN DEPARTAMENTE D ON (A.IdDept=D.IdDept)
JOIN FUNCTII F ON (A.IdFunctie=F.IdFunctie)
GROUP BY D.Denumire

--4. Care sunt produsele vândute într-o anumită perioadă de timp ?
SELECT P.Denumire
FROM PRODUSE P
JOIN VANZARI V ON P.IdProdus = V.IdProdus
WHERE V.DataVanz BETWEEN '11/10/2010' AND '11/10/2017'

--5. Care sunt clienții ce au cumpărat produse prin intermediul unui vânzător anume ?
SELECT C.Denumire Client
FROM CLIENTI C
JOIN VANZARI V ON C.IdClient = V.IdClient
WHERE V.IdVanzator = 13

--6-. Care sunt clienții ce au cumpărat două produse ?
SELECT C.Denumire Client
FROM CLIENTI C
JOIN VANZARI V ON C.IdClient=V.IDClient
GROUP BY C.Denumire
HAVING COUNT(V.IdProdus) = 2

--7. Care sunt clienții ce au cumpărat cel puțin două produse ?
SELECT C.Denumire Client
FROM CLIENTI C
JOIN VANZARI V ON C.IdClient=V.IDClient
GROUP BY C.Denumire
HAVING COUNT(V.IdProdus) >= 2

--8. Câți clienți au cumpărat (la o singură cumpărare) produse în valoare mai mare decât o sumă
--dată (de ex. 200) ?
SELECT COUNT(DISTINCT IdClient) 
FROM VANZARI
WHERE PretVanz * NrProduse > 5

--9. Care sunt clienții din CLUJ care au cumpărat produse în valoare mai mare de 200 ?
SELECT C.Denumire
FROM CLIENTI C
JOIN VANZARI V ON C.IdClient = V.IdClient
WHERE C.Adresa_jud = 'CLUJ' AND V.PretVanz * V.NrProduse > 5
GROUP BY C.Denumire


--10. Care sunt mediile vânzărilor pe o anumită perioadă de timp, grupate pe produse ?
SELECT P.Denumire, AVG(V.PretVanz) AVG_PRICE
FROM VANZARI V
JOIN PRODUSE P ON V.IDProdus=P.IdProdus
WHERE V.DataVanz BETWEEN '11/10/2010' AND '11/10/2017'
GROUP BY P.Denumire

--11. Care este numărul total de produse vândute pe o anumită perioadă de timp ?
SELECT SUM(NrProduse) AS Nr_PRODUSE
FROM VANZARI 
WHERE DataVanz BETWEEN '11/10/2010' AND '11/10/2017'

--12. Care este numărul de total de produse vândute de un vânzător precizat prin nume ?
SELECT SUM(V.NrProduse) AS Nr_PRODUSE
FROM VANZARI V
JOIN ANGAJATI A ON (A.IdAngajat=V.IDVanzator)
WHERE A.Nume = 'N13' -- SAME AS IDVANZATOR 13

--13. Care sunt clienții ce au cumpărat produse în valoare mai mare decât media vânzărilor din luna
--august 2016 ?
SELECT C.Denumire
FROM CLIENTI C
JOIN VANZARI V ON (C.IdClient = V.IDClient)
GROUP BY C.Denumire
HAVING SUM(V.NrProduse*V.PretVanz) > 
		(SELECT AVG(NrProduse*PretVanz) 
			FROM VANZARI WHERE MONTH(DataVanz) = 7 AND YEAR(DataVanz) = 2016 )

--14. Care sunt produsele care s-au vândut la mai mult de un client ?
SELECT P.Denumire, P.IdProdus
FROM PRODUSE P
JOIN VANZARI V ON (P.IdProdus = V.IDProdus)
GROUP BY P.Denumire, P.IdProdus
HAVING COUNT( V.IDClient) > 1


--15. Care sunt vânzările valorice realizate de fiecare vânzător, grupate pe produse și clienți, cu
--subtotaluri ?
SELECT A.Nume AS Vanzator, 
	P.Denumire AS Produs, 
	C.Denumire AS Client, 
	SUM(V.PretVanz * V.NrProduse) AS Vanzari
FROM VANZARI V
JOIN ANGAJATI A ON V.IDVanzator=A.IdAngajat
JOIN PRODUSE P ON P.IdProdus=V.IDProdus
JOIN CLIENTI C ON V.IDClient=C.IdClient
GROUP BY A.Nume, P.Denumire, C.Denumire
ORDER BY A.Nume, P.Denumire, C.Denumire
